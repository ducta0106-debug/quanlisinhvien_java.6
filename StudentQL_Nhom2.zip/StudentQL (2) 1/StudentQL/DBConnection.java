import java.sql.*;

public class DBConnection {
    public static Connection Ketnoi() {
        Connection conn = null;
        String url = "jdbc:mysql://localhost:3306/studentdb?useUnicode=true&characterEncoding=UTF8&serverTimezone=Asia/Ho_Chi_Minh";
        String username = "root";
        String pass = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, username, pass);
            if (conn != null) {
                System.out.println("Kết nối MySQL thành công!");
            }
            return conn;
        } catch (ClassNotFoundException e) {
            System.out.println("Lỗi: Thiếu thư viện MySQL Connector Driver (.jar)");
        } catch (SQLException e) {
            System.out.println("Lỗi SQL: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Lỗi khác: " + e.getMessage());
        }
        return null;
    }
}
