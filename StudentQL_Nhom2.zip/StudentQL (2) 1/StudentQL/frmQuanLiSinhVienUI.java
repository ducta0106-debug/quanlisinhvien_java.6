import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.Vector;
import javax.swing.UIManager;

public class frmQuanLiSinhVienUI extends JFrame {

    // UI Components
    private JPanel         pnlMain;
    private JPanel         pnlSearch;

    // Form nhập liệu
    private JLabel         lblID, lblName, lblAge, lblAddress, lblPhoneNumber, lblGioiTinh, lblAnh;
    private JTextField     txtID, txtName, txtAge, txtDiaChi, txtPhoneNumber;
    private JComboBox<String> cbnGioiTinh;
    private JTable         tableSV;

    // Nút chức năng chính
    private JButton        btnThem, btnSua, btnXoa, btnLuu, btnTimKiem, btnTaiLai, btnTroVe, btnThemAnh;
    private JButton        btnXuatFile;
    // Component tìm kiếm nâng cao
    private JLabel lblSearchTen, lblSearchGioiTinh, lblTuoiMin, lblTuoiMax, lblSearchDiaChi, lblSearchID;
    private JTextField     txtSearchTen, txtSearchDiaChi, txtTuoiMin, txtTuoiMax, txtSearchID;
    private JComboBox<String> cbnSearchGioiTinh;
    private JButton        btnTimKiemNangCao, btnXoaBoLoc;

    // Database
    private Connection        conn;
    private PreparedStatement stmt;
    private ResultSet         rs;

    // Trạng thái
    private boolean isInsert = false;
    private boolean isUpdate = false;
    private String  filename = null;
    private final String vaiTro;

    public frmQuanLiSinhVienUI(String vaiTro) {
        this.vaiTro = (vaiTro != null) ? vaiTro : "giaovien";
        conn = DBConnection.Ketnoi();

        if (cbnSearchGioiTinh != null) {
            cbnSearchGioiTinh.removeAllItems();
            cbnSearchGioiTinh.addItem("Tất cả");
            cbnSearchGioiTinh.addItem("Nam");
            cbnSearchGioiTinh.addItem("Nữ");
            cbnSearchGioiTinh.setSelectedIndex(0);
        }

        this.setContentPane(pnlMain);
        this.setTitle("Quản Lý Sinh Viên [" + getTenVaiTro() + "]");
        this.setSize(1100, 750);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        if (pnlSearch != null) {
            pnlSearch.setBorder(BorderFactory.createTitledBorder(
                    BorderFactory.createEtchedBorder(), "🔍 Tìm kiếm nâng cao"));
        }

        LoadData(buildDefaultQuery(), new Object[]{});
        apDungPhanQuyen();
        EnableSearch(false);
        EnableFields(false);

        dangKySuKien();
        this.setVisible(true);
    }

    public frmQuanLiSinhVienUI() {
        this("admin");
    }


    // PHÂN QUYỀN & TRẠNG THÁI GIAO DIỆN

    // Đổi tên hiển thị giao diện theo vai trò mới
    private String getTenVaiTro() {
        return switch (vaiTro) {
            case "admin"    -> "Quản trị viên";
            case "giaovien" -> "Giáo viên";
            case "sinhvien" -> "Sinh viên - Chỉ xem";
            default         -> vaiTro;
        };
    }
    // Ẩn/Hiện các nút chức năng trên Form theo vai trò
    private void apDungPhanQuyen() {
        switch (vaiTro) {
            case "giaovien" -> {
                btnXoa.setVisible(false);
            }
            case "sinhvien" -> {
                btnThem.setVisible(false);
                btnSua.setVisible(false);
                btnXoa.setVisible(false);
                btnLuu.setVisible(false);
                if (btnThemAnh != null) btnThemAnh.setVisible(false);
                EnableFields(false);
            }
        }
    }

    private void EnableSearch(boolean on) {
        if(txtSearchID != null) txtSearchID.setEnabled(on);
        txtSearchTen.setEnabled(on);
        txtSearchDiaChi.setEnabled(on);
        txtTuoiMin.setEnabled(on);
        txtTuoiMax.setEnabled(on);
        cbnSearchGioiTinh.setEnabled(on);
        btnTimKiemNangCao.setEnabled(on);
        btnXoaBoLoc.setEnabled(on);
    }

    private void EnableFields(boolean on) {
        txtID.setEnabled(on);
        txtName.setEnabled(on);
        txtAge.setEnabled(on);
        txtDiaChi.setEnabled(on);
        txtPhoneNumber.setEnabled(on);
        cbnGioiTinh.setEnabled(on);
        if (btnThemAnh != null) btnThemAnh.setEnabled(on);
    }

    private void ResetFields() {
        txtID.setText("");
        txtName.setText("");
        txtAge.setText("");
        txtDiaChi.setText("");
        txtPhoneNumber.setText("");
        cbnGioiTinh.setSelectedIndex(0);
        if (lblAnh != null) lblAnh.setIcon(null);
        filename = null;
    }

    private void XoaBoLoc() {
        if(txtSearchID != null) txtSearchID.setText("");
        txtSearchTen.setText("");
        txtSearchDiaChi.setText("");
        txtTuoiMin.setText("");
        txtTuoiMax.setText("");
        cbnSearchGioiTinh.setSelectedIndex(0);
    }

    // ĐĂNG KÝ SỰ KIỆN

    private void dangKySuKien() {
        if (btnTimKiem != null) {
            btnTimKiem.addActionListener(e -> {
                EnableSearch(true); EnableFields(false);
                setButtonStateForEdit(false);
            });
        }
        btnTimKiemNangCao.addActionListener(e -> TimKiemNangCao());

        btnXoaBoLoc.addActionListener(e -> {
            XoaBoLoc();
            LoadData(buildDefaultQuery(), new Object[]{});
        });

        btnThem.addActionListener(e -> {
            ResetFields();
            EnableFields(true);
            EnableSearch(false);
            setButtonStateForEdit(true); isInsert = true; isUpdate = false;
            txtID.requestFocus();
        });

        btnSua.addActionListener(e -> {
            int row = tableSV.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(pnlMain, "Vui lòng chọn 1 sinh viên trên bảng để sửa!"); return;
            }
            EnableFields(true);
            EnableSearch(false);
            txtID.setEnabled(false); // Không cho sửa khóa chính
            setButtonStateForEdit(true); isInsert = false; isUpdate = true;
        });

        btnLuu.addActionListener(e -> {
            if (isInsert) LuuThem(); else if (isUpdate) LuuSua();
        });
        btnXuatFile.addActionListener(e -> {
            xuatFileCSV();
        });
        btnXoa.addActionListener(e -> XoaSinhVien());

        btnTaiLai.addActionListener(e -> {
            XoaBoLoc(); LoadData(buildDefaultQuery(), new Object[]{});
            EnableSearch(false);
        });

        btnTroVe.addActionListener(e -> {
            dispose(); new frmDangNhapUI();
        });

        if (btnThemAnh != null) { btnThemAnh.addActionListener(e -> ChonAnh()); }

        tableSV.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { HienThiChiTiet(); }
        });

        KeyAdapter enterSearch = new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER && btnTimKiemNangCao.isEnabled()) {
                    TimKiemNangCao();
                }
            }
        };

        if(txtSearchID != null) txtSearchID.addKeyListener(enterSearch);
        txtSearchTen.addKeyListener(enterSearch);
        txtSearchDiaChi.addKeyListener(enterSearch);
        txtTuoiMin.addKeyListener(enterSearch);
        txtTuoiMax.addKeyListener(enterSearch);
    }

    // TÌM KIẾM NÂNG CAO & LOAD DATA

    private void TimKiemNangCao() {
        StringBuilder sql = new StringBuilder("SELECT * FROM sinhvien WHERE 1=1");
        java.util.List<Object> params = new java.util.ArrayList<>();

        // 1. Tìm theo ID
        if (txtSearchID != null && !txtSearchID.getText().trim().isEmpty()) {
            try {
                sql.append(" AND ID = ?");
                params.add(Integer.parseInt(txtSearchID.getText().trim()));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(pnlMain, "Mã sinh viên (ID) phải là số!"); return;
            }
        }

        // 2. Tìm theo Tên
        String ten = txtSearchTen.getText().trim();
        if (!ten.isEmpty()) {
            sql.append(" AND Ten LIKE ?");
            params.add("%" + ten + "%");
        }

        // 3. Tìm theo Giới tính
        Object selectedGt = cbnSearchGioiTinh.getSelectedItem();
        String gt = (selectedGt != null) ? selectedGt.toString() : "Tất cả";
        if (!gt.equals("Tất cả")) {
            sql.append(" AND GioiTinh = ?");
            params.add(gt);
        }

        // 4. Tìm theo Tuổi
        String tuoiMinStr = txtTuoiMin.getText().trim();
        if (!tuoiMinStr.isEmpty()) {
            try {
                sql.append(" AND Tuoi >= ?");
                params.add(Integer.parseInt(tuoiMinStr));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(pnlMain, "Tuổi từ phải là số nguyên!"); return;
            }
        }

        String tuoiMaxStr = txtTuoiMax.getText().trim();
        if (!tuoiMaxStr.isEmpty()) {
            try {
                sql.append(" AND Tuoi <= ?");
                params.add(Integer.parseInt(tuoiMaxStr));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(pnlMain, "Tuổi đến phải là số nguyên!"); return;
            }
        }

        // 5. Tìm theo Địa chỉ OR SĐT
        String diaChiSDT = txtSearchDiaChi.getText().trim();
        if (!diaChiSDT.isEmpty()) {
            sql.append(" AND (DiaChi LIKE ? OR CAST(SDT AS CHAR) LIKE ?)");
            params.add("%" + diaChiSDT + "%");
            params.add("%" + diaChiSDT + "%");
        }

        LoadData(sql.toString(), params.toArray());
    }

    private String buildDefaultQuery() {
        return "SELECT * FROM sinhvien";
    }
    private void xuatFileCSV() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Lưu file danh sách sinh viên");
        fileChooser.setSelectedFile(new java.io.File("DanhSachSV.csv"));

        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            java.io.File file = fileChooser.getSelectedFile();

            try (java.io.BufferedWriter bw = new java.io.BufferedWriter(
                    new java.io.OutputStreamWriter(new java.io.FileOutputStream(file), "UTF-8"))) {

                //Nhận diện đúng tiếng Việt UTF-8
                bw.write('\ufeff');
                javax.swing.table.TableModel model = tableSV.getModel();
                int colCount = model.getColumnCount();

                // Ghi Header
                for (int i = 0; i < colCount; i++) {
                    bw.write(model.getColumnName(i));
                    if (i < colCount - 1) bw.write(",");
                }
                bw.newLine();

                // Ghi Data
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < colCount; j++) {
                        Object val = model.getValueAt(i, j);
                        String s = (val != null) ? val.toString().replace(",", " ") : ""; // Khử dấu phẩy trong dữ liệu
                        bw.write(s);
                        if (j < colCount - 1) bw.write(",");
                    }
                    bw.newLine();
                }
                JOptionPane.showMessageDialog(this, "Đã xuất file thành công tại: " + file.getAbsolutePath());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi xuất file: " + ex.getMessage());
            }
        }
    }
    private void LoadData(String sql, Object[] params) {
        ResetFields();
        applyBaseButtonState();

        try {
            stmt = conn.prepareStatement(sql);
            for (int i = 0; i < params.length; i++) {
                stmt.setObject(i + 1, params[i]);
            }
            rs = stmt.executeQuery();

            Vector<String> columns = new Vector<>();
            columns.add("Mã SV"); columns.add("Họ Tên"); columns.add("Tuổi");
            columns.add("Sex"); columns.add("SĐT"); columns.add("Địa Chỉ");

            Vector<Vector<Object>> data = new Vector<>();
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("ID"));
                row.add(rs.getString("Ten"));
                row.add(rs.getInt("Tuoi"));
                row.add(rs.getString("GioiTinh"));

                // Sửa lỗi hiển thị mất số 0 ở SĐT
                String sdt = rs.getString("SDT");
                if (sdt != null && !sdt.startsWith("0")) {
                    sdt = "0" + sdt; // Tự động chèn số 0 nếu DB đang lưu kiểu số nguyên làm mất số 0
                }
                row.add(sdt);

                row.add(rs.getString("DiaChi"));
                data.add(row);
            }
            tableSV.setModel(new DefaultTableModel(data, columns) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            });
        } catch (Exception e) {
            JOptionPane.showMessageDialog(pnlMain, "Lỗi LoadData: " + e.getMessage());
        }
    }

    // CÁC THAO TÁC CRUD

    private void LuuThem() {
        // 1. Kiểm tra dữ liệu đầu vào
        StringBuilder sb = new StringBuilder();

        if (txtID.getText().trim().isEmpty()) sb.append("ID không được để trống!\n");
        if (txtName.getText().trim().isEmpty()) sb.append("Tên không được để trống!\n");
        if (txtAge.getText().trim().isEmpty()) sb.append("Tuổi không được để trống!\n");
        if (txtPhoneNumber.getText().trim().isEmpty()) sb.append("Số điện thoại không được để trống!\n");
        if (txtDiaChi.getText().trim().isEmpty()) sb.append("Địa chỉ không được để trống!\n");

        // Kiểm tra ComboBox giới tính (nếu bạn có mục mặc định là "Chọn giới tính")
        if (cbnGioiTinh.getSelectedIndex() == -1) {
            sb.append("Vui lòng chọn giới tính!\n");
        }

        if (sb.length() > 0) {
            JOptionPane.showMessageDialog(pnlMain, sb.toString(), "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return; // Dừng thực hiện nếu có lỗi
        }

        // 2. Thực hiện lưu vào Database
        String sql = "INSERT INTO sinhvien (ID, Ten, Tuoi, GioiTinh, SDT, DiaChi, Anh) VALUES (?,?,?,?,?,?,?)";
        try {
            stmt = conn.prepareStatement(sql);

            // Chuyển đổi số sau khi đã chắc chắn text không trống
            stmt.setInt(1, Integer.parseInt(txtID.getText().trim()));
            stmt.setString(2, txtName.getText().trim());
            stmt.setInt(3, Integer.parseInt(txtAge.getText().trim()));
            stmt.setString(4, cbnGioiTinh.getSelectedItem().toString());
            stmt.setString(5, txtPhoneNumber.getText().trim());
            stmt.setString(6, txtDiaChi.getText().trim());

            if (filename != null) {
                stmt.setBinaryStream(7, new FileInputStream(new File(filename)));
            } else {
                stmt.setNull(7, java.sql.Types.BLOB);
            }

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(pnlMain, "Thêm sinh viên thành công!");

            // Reset form và cập nhật bảng
            LoadData(buildDefaultQuery(), new Object[]{});
            setButtonStateForEdit(false);
            EnableFields(false);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(pnlMain, "ID và Tuổi phải là ký tự số!", "Lỗi định dạng", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(pnlMain, "Lỗi Database: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void LuuSua() {
        String sql = "UPDATE sinhvien SET Ten=?, Tuoi=?, GioiTinh=?, SDT=?, DiaChi=?" +
                (filename != null ? ", Anh=?" : "") + " WHERE ID=?";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, txtName.getText().trim());
            stmt.setInt(2, Integer.parseInt(txtAge.getText().trim()));
            stmt.setString(3, cbnGioiTinh.getSelectedItem().toString());

            // Xử lý SĐT dưới dạng String để giữ số 0
            stmt.setString(4, txtPhoneNumber.getText().trim());

            stmt.setString(5, txtDiaChi.getText().trim());

            if (filename != null) {
                stmt.setBinaryStream(6, new FileInputStream(new File(filename)));
                stmt.setInt(7, Integer.parseInt(txtID.getText().trim()));
            } else {
                stmt.setInt(6, Integer.parseInt(txtID.getText().trim()));
            }

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(pnlMain, "Cập nhật thành công!");
            LoadData(buildDefaultQuery(), new Object[]{});
            setButtonStateForEdit(false);
            EnableFields(false);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(pnlMain, "Tuổi phải là số!", "Lỗi", JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(pnlMain, "Lỗi Database: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void XoaSinhVien() {
        int row = tableSV.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(pnlMain, "Vui lòng chọn sinh viên cần xóa trên bảng!");
            return;
        }
        int id = Integer.parseInt(tableSV.getValueAt(row, 0).toString());
        if (JOptionPane.showConfirmDialog(pnlMain, "XÓA sinh viên ID " + id + "?", "Xác nhận",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                stmt = conn.prepareStatement("DELETE FROM sinhvien WHERE ID = ?");
                stmt.setInt(1, id);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(pnlMain, "Đã xóa thành công!");
                LoadData(buildDefaultQuery(), new Object[]{});
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(pnlMain, "Lỗi khi xóa: " + ex.getMessage());
            }
        }
    }

    private void ChonAnh() {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new FileNameExtensionFilter("Images", "jpg", "png", "jpeg", "gif"));
        if (fc.showOpenDialog(pnlMain) == JFileChooser.APPROVE_OPTION) {
            filename = fc.getSelectedFile().getAbsolutePath();
            try {
                ImageIcon icon = new ImageIcon(new ImageIcon(filename).getImage()
                        .getScaledInstance(lblAnh.getWidth(), lblAnh.getHeight(), Image.SCALE_SMOOTH));
                lblAnh.setIcon(icon);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(pnlMain, "Lỗi hiển thị ảnh!");
            }
        }
    }

    private void HienThiChiTiet() {
        int row = tableSV.getSelectedRow();
        if (row == -1) return;

        txtID.setText(tableSV.getValueAt(row, 0).toString());
        txtName.setText(tableSV.getValueAt(row, 1).toString());
        txtAge.setText(tableSV.getValueAt(row, 2).toString());
        cbnGioiTinh.setSelectedItem(tableSV.getValueAt(row, 3).toString());

        // Cập nhật lấy sdt ra ô TextField
        String sdt = tableSV.getValueAt(row, 4).toString();
        txtPhoneNumber.setText(sdt);

        txtDiaChi.setText(tableSV.getValueAt(row, 5).toString());

        try {
            stmt = conn.prepareStatement("SELECT Anh FROM sinhvien WHERE ID = ?");
            stmt.setInt(1, Integer.parseInt(txtID.getText()));
            rs = stmt.executeQuery();
            if (rs.next()) {
                byte[] imgBytes = rs.getBytes("Anh");
                lblAnh.setIcon(imgBytes != null ? new ImageIcon(new ImageIcon(imgBytes).getImage()
                        .getScaledInstance(lblAnh.getWidth(), lblAnh.getHeight(), Image.SCALE_SMOOTH)) : null);
            }
        } catch (Exception ex) {
            System.out.println("Lỗi load ảnh: " + ex.getMessage());
        }
    }

    private void applyBaseButtonState() {

        boolean canEdit = !vaiTro.equals("sinhvien");
        boolean canDelete = vaiTro.equals("admin");

        if (btnThem != null) btnThem.setEnabled(canEdit);
        if (btnSua  != null) btnSua.setEnabled(canEdit);
        if (btnXoa  != null) btnXoa.setEnabled(canDelete);
        if (btnLuu  != null) btnLuu.setEnabled(false);
        isInsert = false;
        isUpdate = false;
    }

    private void setButtonStateForEdit(boolean editing) {
        if (btnThem != null) btnThem.setEnabled(!editing);
        if (btnSua  != null) btnSua.setEnabled(!editing);
        if (btnXoa  != null) btnXoa.setEnabled(!editing);
        if (btnLuu  != null) btnLuu.setEnabled(editing);
    }
    //MAIN
    public static void main(String[] args) {
        try {
            // Cấu hình bo góc tròn trịa hơn
            UIManager.put("Button.arc", 15);
            UIManager.put("Component.arc", 15);
            UIManager.put("TextComponent.arc", 15);

            // ÉP MÀU XANH CHO TOÀN BỘ NÚT BẤM
            Color modernBlue = new Color(21, 124, 219);
            UIManager.put("Button.background", modernBlue);                   // Nền nút màu xanh
            UIManager.put("Button.foreground", Color.WHITE);                  // Chữ trên nút màu trắng
            UIManager.put("Button.hoverBackground", new Color(51, 153, 255)); // Đổi màu sáng hơn khi di chuột vào

            //  Màu của các thành phần khác (viền , bảng...)
            UIManager.put("Component.focusColor", modernBlue);
            UIManager.put("Component.accentColor", modernBlue);

            UIManager.put("Table.showHorizontalLines", true);
            UIManager.put("Table.showVerticalLines", true);
            UIManager.put("Table.gridColor", new Color(180,180,180));

            UIManager.put("Table.selectionBackground", new Color(51, 153, 255));
            UIManager.put("Table.selectionForeground", Color.WHITE);

            UIManager.put("TableHeader.background", new Color(230,230,230));
            // Khởi tạo FlatLaf
            com.formdev.flatlaf.FlatLightLaf.setup();

        } catch (Exception ex) {
            System.err.println("Không thể khởi tạo FlatLaf");
        }

        SwingUtilities.invokeLater(() -> {
            new frmQuanLiSinhVienUI("admin");
            new frmQuanLiSinhVienUI("giaovien");
            new frmQuanLiSinhVienUI("sinhvien");

        });
    }
    }
