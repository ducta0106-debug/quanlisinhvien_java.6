import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.UIManager;

public class frmDangNhapUI extends JFrame {

    // UI Components
    private JPanel      pnlMain;
    private JLabel      lblUser;
    private JLabel      lblPass;
    private JTextField  txtUser;
    private JPasswordField txtPass;
    private JButton     btnDangNhap;
    private JButton     btnThoat;

    // Database
    private Connection        conn;
    private PreparedStatement stmt;
    private ResultSet         rs;

    // Constructor
    public frmDangNhapUI() {
        conn = DBConnection.Ketnoi();


        this.setContentPane(pnlMain);

        this.setTitle("Đăng Nhập Hệ Thống");
        this.setSize(500, 300);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

        // Nút Thoát
        btnThoat.addActionListener(e -> System.exit(0));

        // Nút Đăng Nhập
        btnDangNhap.addActionListener(e -> DangNhap());

        // Phím Enter
        txtPass.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) DangNhap();
            }
        });
    }

    // Logic Đăng Nhập
    private void DangNhap() {
        String tenDN  = txtUser.getText().trim();
        String matKhau = new String(txtPass.getPassword()).trim();
        if (tenDN.isEmpty() || matKhau.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu!",
                    "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String sql = "SELECT VaiTro FROM TaiKhoan WHERE ten = ? AND matkhau = ?";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, tenDN);
            stmt.setString(2, matKhau);
            rs = stmt.executeQuery();
            if (rs.next()) {
                String vaiTro = rs.getString("VaiTro"); // "admin" / "nhanvien" / "giaovien"
                // Hiển thị thông báo tên + vai trò
                String tenHienThi = switch (vaiTro) {
                    case "admin"     -> "Quản trị viên (Admin)";
                    case "sinhvien"  -> "Sinh Viên (Chỉ xem )";
                    case "giaovien"  -> "Giáo viên ";
                    default          -> vaiTro;
                };
                JOptionPane.showMessageDialog(this,
                        "Xin chào " + tenDN + "!\nVai trò: " + tenHienThi,
                        "Đăng nhập thành công", JOptionPane.INFORMATION_MESSAGE);
                this.dispose();
                // Truyền vaiTro sang form quản lý
                new frmQuanLiSinhVienUI(vaiTro);
            } else {
                JOptionPane.showMessageDialog(this,
                        "Sai tên đăng nhập hoặc mật khẩu!",
                        "Thông báo", JOptionPane.WARNING_MESSAGE);
                txtPass.setText("");
                txtUser.requestFocus();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Lỗi Đăng Nhập: " + e.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        try {
            //Cấu hình bo góc tròn trịa hơn
            UIManager.put("Button.arc", 15);
            UIManager.put("Component.arc", 15);
            UIManager.put("TextComponent.arc", 15);
            UIManager.put("Table.showHorizontalLines", true);
            UIManager.put("Table.showVerticalLines", true);
            UIManager.put("Table.gridColor", new Color(180,180,180));

            UIManager.put("Table.selectionBackground", new Color(51,153,255));
            UIManager.put("Table.selectionForeground", Color.WHITE);

            UIManager.put("TableHeader.background", new Color(230,230,230));
            //ÉP MÀU XANH CHO TOÀN BỘ NÚT BẤM
            Color modernBlue = new Color(21, 124, 219);
            UIManager.put("Button.background", modernBlue);                   // Nền nút màu xanh
            UIManager.put("Button.foreground", Color.WHITE);                  // Chữ trên nút màu trắng
            UIManager.put("Button.hoverBackground", new Color(51, 153, 255));
            // Kích hoạt FlatLaf
            UIManager.setLookAndFeel(new com.formdev.flatlaf.FlatLightLaf());
        } catch (Exception ex) {
            System.err.println("Không thể khởi tạo FlatLaf");
        }
        // Chạy màn hình đăng nhập
        SwingUtilities.invokeLater(frmDangNhapUI::new);
    }
}
